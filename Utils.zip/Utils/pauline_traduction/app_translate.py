import os
import io
import shutil
import tempfile
from pathlib import Path
from typing import Tuple, Optional

import gradio as gr
import requests
from pydub import AudioSegment
import moviepy.editor as mp
import whisper

# =========================
# Constantes & Config
# =========================
AUDIO_EXTS = {".wav", ".mp3", ".m4a", ".aac", ".flac", ".ogg"}
VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".avi", ".webm"}

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434/api/chat")
MODEL = os.environ.get("OLLAMA_MODEL", "gpt-oss:120b")
TIMEOUT_SECONDS = int(os.environ.get("OLLAMA_TIMEOUT", "600"))

SYSTEM_PROMPT_SADDLE = (
    "Vous êtes traducteur professionnel spécialisé en sellerie et fabrication de selles. "
    "Vous maîtrisez parfaitement la terminologie : arçon, quartiers, panneaux, sanglage, assise, taquets, rembourrage. "
    "Équivalences obligatoires : "
    "- Anglais → Français : tree = arçon, waist = taille de l’arçon, web = sangle, seat = assise, skirt = jupe, blocks = taquets. "
    "- Anglais → Allemand : tree = Baum, waist = Kammerweite, web = Gurtstrupfen, seat = Sitz, skirt = Sattelblatt, blocks = Pauschen. "
    "Règles : "
    "1. Tous les termes techniques doivent toujours être traduits exactement dans la langue cible. "
    "2. Aucun terme ne doit rester dans une autre langue. "
    "3. La traduction doit être fidèle, naturelle et idiomatique, en respectant le ton et les nuances du texte original. "
    "4. La sortie doit être uniquement dans la langue cible, sans guillemets ni commentaires."
)

LANG_NAMES = {
    "fr": "français",
    "en": "anglais",
    "de": "allemand",
    "es": "espagnol",
    "it": "italien",
    "pt": "portugais",
    "ar": "arabe",
}

def call_ollama(text: str, tgt_lang: str) -> str:
    lang_name = LANG_NAMES.get(tgt_lang, tgt_lang)

    sys_prompt = SYSTEM_PROMPT_SADDLE
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": f"Langue cible : {lang_name}\n\nTexte à traduire :\n{text}"},
        ],
        "stream": False,
    }
    r = requests.post(OLLAMA_URL, json=payload, timeout=TIMEOUT_SECONDS)
    r.raise_for_status()
    data = r.json()
    if "message" in data and "content" in data["message"]:
        return data["message"]["content"].strip()
    elif "response" in data:
        return data["response"].strip()
    else:
        raise RuntimeError(f"Réponse inattendue: {data}")

# Cache simple des modèles Whisper pour éviter les rechargements
_WHISPER_CACHE = {}

def _get_whisper(model_size: str):
    if model_size not in _WHISPER_CACHE:
        _WHISPER_CACHE[model_size] = whisper.load_model(model_size)
    return _WHISPER_CACHE[model_size]

def extract_audio_from_video(video_path: str, output_audio_path: str) -> str:
    """Extrait l'audio d'une vidéo vers un WAV via moviepy/ffmpeg."""
    video = mp.VideoFileClip(video_path)
    audio = video.audio
    audio.write_audiofile(output_audio_path, logger=None)
    return output_audio_path

def prepare_audio_from_any(input_path: str, tmpdir: str) -> str:
    """Retourne le chemin d'un WAV prêt pour Whisper, depuis une vidéo ou un audio."""
    ext = Path(input_path).suffix.lower()
    out_wav = os.path.join(tmpdir, "audio.wav")

    if ext in VIDEO_EXTS:
        return extract_audio_from_video(input_path, out_wav)

    if ext in AUDIO_EXTS:
        if ext == ".wav":
            shutil.copyfile(input_path, out_wav)
        else:
            audio = AudioSegment.from_file(input_path)
            audio.export(out_wav, format="wav")
        return out_wav

    raise ValueError(
        f"Extension non supportée: {ext} (audio: {AUDIO_EXTS}, vidéo: {VIDEO_EXTS})"
    )

def transcribe_segments(audio_path: str, model_size="large-v3", language: Optional[str] = None):
    model = _get_whisper(model_size)
    result = model.transcribe(
        audio_path,
        language=language,                 # None => auto
        verbose=False,
        temperature=0.0,                   # moins d’hésitation
        best_of=5,                         # pour sampling si temperature>0
        beam_size=5,                       # pour beam search
        condition_on_previous_text=False,  # évite la propagation d’erreurs
    )
    segments = result.get("segments", [])
    lang = result.get("language", language or "en")
    return segments, lang

def save_text_to_md(text: str, output_path: Path) -> Path:
    output_path = Path(output_path).with_suffix(".md")
    output_path.write_text(text, encoding="utf-8")
    return output_path

# =========================
# Fonctions Gradio
# =========================

def process_all(file_obj, model_size, src_lang, tgt_lang):
    if file_obj is None:
        return gr.update(value="", visible=True), "", "", "", None, None, None

    with tempfile.TemporaryDirectory() as tmpdir:
        in_path = Path(tmpdir) / (file_obj.name or "input")
        if hasattr(file_obj, "name") and Path(getattr(file_obj, "name", "")).exists():
            in_path = Path(getattr(file_obj, "name"))
        else:
            with open(in_path, "wb") as f:
                f.write(file_obj.read())

        # Transcription
        wav_path = prepare_audio_from_any(str(in_path), tmpdir)
        lang_arg = None if src_lang == "auto" else src_lang
        segments, detected = transcribe_segments(wav_path, model_size=model_size, language=lang_arg)
        transcription_text = " ".join(seg.get("text", "") for seg in segments).strip()

        # Traduction
        translated_text = call_ollama(transcription_text, tgt_lang)

        # Résumé
        summary_text = call_ollama(f"Faites un résumé détaillé et précis du texte suivant :\n{translated_text}\nRésumé :", model_size)

        # Sauvegarde des fichiers MD
        with tempfile.NamedTemporaryFile(suffix=".md", delete=False) as temp_file:
            temp_file_path = temp_file.name
            with open(temp_file_path, "w", encoding="utf-8") as f:
                f.write(transcription_text)
            dl_transcript_path = temp_file_path

        with tempfile.NamedTemporaryFile(suffix=".md", delete=False) as temp_file:
            temp_file_path = temp_file.name
            with open(temp_file_path, "w", encoding="utf-8") as f:
                f.write(translated_text)
            dl_translation_path = temp_file_path

        with tempfile.NamedTemporaryFile(suffix=".md", delete=False) as temp_file:
            temp_file_path = temp_file.name
            with open(temp_file_path, "w", encoding="utf-8") as f:
                f.write(summary_text)
            dl_summary_path = temp_file_path

        return transcription_text, translated_text, summary_text, detected, dl_transcript_path, dl_translation_path, dl_summary_path

# =========================
# Interface Gradio
# =========================
with gr.Blocks(title="Transcription & Traduction (Whisper → Ollama)") as demo:
    gr.Markdown(""" 
    # 📝 Transcription & Traduction (Whisper → Ollama)
    Chargez une **vidéo** ou un **audio**, choisissez la **langue source** et la **langue cible**,
    puis lancez la **transcription**, la **traduction** et le **résumé** en un seul clic.

    *Astuce : assurez‑vous que **ffmpeg** est installé et accessible (requis par moviepy/pydub).*  
    *Variables d'environnement : `OLLAMA_URL`, `OLLAMA_MODEL`, `OLLAMA_TIMEOUT`.* 
    """)

    with gr.Row():
        file_in = gr.File(label="Fichier audio/vidéo", file_count="single", file_types=list(AUDIO_EXTS | VIDEO_EXTS))

    with gr.Row():
        model_size = gr.Dropdown(
            ["tiny", "base", "small", "medium", "large", "large-v2", "large-v3"],
            value="large-v3",
            label="Modèle Whisper",
            info="Plus le modèle est grand, plus la précision est élevée (mais plus lent).",
        )
        src_lang = gr.Dropdown(
            ["auto", "en", "fr", "de", "es", "it", "pt", "ar"],
            value="en",
            label="Langue d'entrée (source)",
            info="Langue de la video, audio",
        )
        tgt_lang = gr.Dropdown(
            ["fr", "en", "de", "es", "it"],
            value="fr",
            label="Langue de traduction (cible)",
            info="Langue de sortie",

        )

    with gr.Row():
        # Nouveau bouton pour lancer toutes les actions en même temps
        btn_all_in_one = gr.Button("Exécuter Transcription → Traduction → Résumé")

    with gr.Row():
        transcript_box = gr.Textbox(label="Transcription", lines=12)
        translation_box = gr.Textbox(label="Traduction", lines=12)
        summary_box = gr.Textbox(label="Résumé de la traduction", lines=12)

    with gr.Row():
        detected_lang_box = gr.Textbox(label="Langue détectée", interactive=False)

    with gr.Row():
        dl_transcript = gr.File(label="Télécharger la transcription (.md)")
        dl_translation = gr.File(label="Télécharger la traduction (.md)")
        dl_summary = gr.File(label="Télécharger le résumé (.md)")

    # Lier le bouton à la nouvelle fonction
    btn_all_in_one.click(process_all, inputs=[file_in, model_size, src_lang, tgt_lang], outputs=[transcript_box, translation_box, summary_box, detected_lang_box, dl_transcript, dl_translation, dl_summary])

if __name__ == "__main__":
    demo.launch(server_name="127.0.0.1",server_port=6070,debug=True,root_path="/traducteur")
