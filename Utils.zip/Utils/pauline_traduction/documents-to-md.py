import os
import re
import shutil
import tempfile
from pathlib import Path

import whisper
from pydub import AudioSegment
import moviepy.editor as mp


AUDIO_EXTS = {".wav", ".mp3", ".m4a", ".aac", ".flac", ".ogg"}
VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".avi", ".webm"}



# =========================
# Pipeline de transcription Whisper
# =========================
def transcribe_segments(audio_path: str, model_size="large-v3", language=None):
    model = whisper.load_model(model_size)
    result = model.transcribe(
        audio_path,
        language=language,                 # None => auto
        verbose=False,
        temperature=0.0,                   # moins d’hésitation
        best_of=5,                         # pour sampling si temperature>0
        beam_size=5,                       # pour beam search
        condition_on_previous_text=False,  # évite la propagation d’erreurs
    )
    segments = result.get("segments", [])
    lang = result.get("language", language or "en")
    return segments, lang


def extract_audio_from_video(video_path: str, output_audio_path: str) -> str:
    video = mp.VideoFileClip(video_path)
    audio = video.audio
    audio.write_audiofile(output_audio_path, logger=None)
    return output_audio_path


def prepare_audio_from_any(input_path: str, tmpdir: str) -> str:
    """Retourne le chemin d'un WAV prêt pour Whisper, depuis une vidéo ou un audio."""
    input_path = str(input_path)
    ext = Path(input_path).suffix.lower()
    out_wav = os.path.join(tmpdir, "audio.wav")

    if ext in VIDEO_EXTS:
        return extract_audio_from_video(input_path, out_wav)

    if ext in AUDIO_EXTS:
        if ext == ".wav":
            shutil.copyfile(input_path, out_wav)
        else:
            audio = AudioSegment.from_file(input_path)
            audio.export(out_wav, format="wav")
        return out_wav

    raise ValueError(f"Extension non supportée: {ext} (audio: {AUDIO_EXTS}, vidéo: {VIDEO_EXTS})")


def save_transcription_as_md(segments, output_path):
    output_path = Path(output_path).with_suffix(".md")
    all_text = " ".join(seg.get("text", "") for seg in segments).strip()
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(all_text)
    print(f"[✅] Transcription enregistrée dans : {output_path}")


def structured_transcription_pipeline(
    video_path,
    output_text_path,
    model_size="large",
    src_lang=None     # None => Whisper auto-detect
):
    video_path = str(video_path)
    output_text_path = Path(output_text_path)
    print(f"Input: {video_path}")
    print(f"Output: {output_text_path}")

    with tempfile.TemporaryDirectory() as tmpdir:
        # 1 - Préparer l'audio (WAV)
        audio_path = prepare_audio_from_any(video_path, tmpdir)

        # 2 - Transcription (langue détectée si src_lang=None)
        segments, detected = transcribe_segments(audio_path, model_size=model_size, language=src_lang)
        
        # 3 - Sauvegarde transcription brute
        save_transcription_as_md(segments, output_text_path)


if __name__ == "__main__":
    # Exemple d'entrée
    doc_in = "/var/www/RAG/Data/videos_Pauline/Audio Cath.m4a"
    doc_out = "/var/www/RAG/Data_parse/transcription_finale.md"

    structured_transcription_pipeline(
        video_path=doc_in,
        output_text_path=doc_out,
        model_size="large",  # Ou autre taille selon vos besoins
        src_lang=None,   # Laissez Whisper détecter la langue source
    )
