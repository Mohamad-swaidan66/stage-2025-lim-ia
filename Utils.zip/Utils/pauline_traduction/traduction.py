import requests
from pathlib import Path

OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL = "gpt-oss:120b"
TIMEOUT_SECONDS = 600   
SYSTEM_PROMPT = (
    "Vous êtes un traducteur professionnel expert en sellerie, maroquinerie et fabrication de selles. "
    "Vous maîtrisez parfaitement la terminologie technique en français, notamment les termes : arçon, quartiers, panneaux, sanglage, assise, taquets, rembourrage, "
    "ainsi que les équivalences spécifiques : 'tree' = arçon, 'waist' = taille de l’arçon, 'web' = sangle, 'seat' = assise, 'skirt' = jupe, 'blocks' = taquets. "
    "Votre mission est de traduire fidèlement tout texte anglais en français, en restituant rigoureusement le sens, les nuances techniques et le ton du texte original. "
    "La traduction doit utiliser un vocabulaire précis, reconnu des professionnels du secteur, et bannir toute approximation terminologique. "
    "Le texte final doit être fluide, idiomatique, clair et rédigé dans un français naturel et professionnel, adapté à une publication spécialisée. "
    "Évitez absolument les calques de l’anglais, les familiarités, les lourdeurs de style et les répétitions inutiles. "
    "Vous devez produire une qualité équivalente à celle d’un traducteur expert, au niveau publication, "
    "en garantissant toujours la cohérence stylistique et terminologique. "
    "Fournissez uniquement la traduction finale, sans guillemets, sans explications et sans commentaires supplémentaires."
)



def translate_en_to_fr(text: str) -> str:
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": text}
        ],
        "stream": False
    }
    r = requests.post(OLLAMA_URL, json=payload, timeout=TIMEOUT_SECONDS)
    r.raise_for_status()
    data = r.json()
    if "message" in data and "content" in data["message"]:
        return data["message"]["content"].strip()
    elif "response" in data:
        return data["response"].strip()
    else:
        raise RuntimeError(f"Réponse inattendue: {data}")


# =========================
# Main
# =========================
if __name__ == "__main__":
    doc_in = "/var/www/RAG/Data_parse/transcription_finale.md"
    doc_out = "/var/www/RAG/Data_parse/traduction.md"

    text = Path(doc_in).read_text(encoding="utf-8")
    translated = translate_en_to_fr(text)
    Path(doc_out).write_text(translated, encoding="utf-8")


